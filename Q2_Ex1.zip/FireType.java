/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q2_exercise1;

/**
 *
 * @author MUON
 */
public class FireType extends Monster {
    protected int atk = base * 1.3;
    protected int def = base * 0.7;
    
    public void special(FireType f){
        atk ++ 2;
        maxHP -= maxHP * 0.10;
        System.out.println(name + " did a pose.");
    }
}
