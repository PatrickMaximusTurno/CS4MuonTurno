/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package q2_ex1;

/**
 *
 * @author Patrick{
    /*
 
 * @author MUON
 */
   public class FireType extends Monster {
    public FireType(String name, String type, int hp, int base){
        super(name, "fire", "grass", "water", hp, base);
        atk *= 1.3;
        def *= 0.7;
    }
            
    
    public void special(FireType f){
        atk += 2;
        hp -= maxHP * 0.10;
        System.out.println(name + " did a pose.");
    }
}


