/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package q2_ex1;

/**
 *
 * @author Patrick
 */
public class GrassType extends Monster {
    public GrassType(String name, String type, int hp, int base){
        super (name, "grass", "water", "fire", hp, base);
       
    }
            
    public void rest(GrassType g){
        hp += maxHP * 0.50;
        if(hp > maxHP) hp = maxHP;
        System.out.println(name + " rested. It's health is now " + hp + ".");
    }
    public void special(GrassType g){
        
        maxHP += maxHP * 0.20;
        System.out.println(name + " did a pose.");
    }
    }

