/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q2_exercise1;

/**
 *
 * @author MUON
 */
public class WaterType extends Monster{
    atk * 0.7;
    protected int def = base * 1.3;
    
    public void special(WaterType w){
        def ++ 10;
        maxHP -= maxHP * 0.10;
        System.out.println(name + " did a pose.");
    }
    
    public void special(FireType f){
        def ++ 10;
        maxHP -= maxHP * 0.10;
        System.out.println(name + " did a pose.");
    }
}
