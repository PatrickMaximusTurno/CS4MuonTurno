/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package q2_ex1;

/**
 *
 * @author Patrick
 */
public class Q2_Ex1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        FireType f = new FireType("c", "fire", 200, 15);
        GrassType g = new GrassType("b", "grass", 200, 15);
        WaterType w = new WaterType("s", "water", 200, 15);
       
      
            
}
