/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q2_exercise2;

/**
 *
 * @author MUON
 */
public class GrassType extends Monster{
    
    public GrassType(String name, String type, int hp, int base){
        super(name, "grass","water", "fire", hp, base);
        
    }
    public void rest(GrassType g){
        hp += maxHP * 0.50;
        if(hp > maxHP) hp = maxHP;
        System.out.println(name + " rested. It's health is now " + hp + ".");
    }
    
    @Override
    public void special(){
        
        maxHP += maxHP * 0.20;
        System.out.println(name + " did a pose.");
    }
    }
