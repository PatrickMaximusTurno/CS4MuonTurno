/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q2_exercise9;
import java.util.ArrayList;

public class Trainer {
	private String name;
    private Monster activeMonster;
    private ArrayList<Monster> team;

    public Trainer(String n){
        this.name = n;
        this.activeMonster = null;
        this.team = new ArrayList<>();
    }
    
    private String getName(){
        return name;
    }

    public Monster getActiveMonster(){
        return activeMonster;
    }
    public ArrayList<Monster> getTeam(){
        return team;
    }

    public void capture(Monster m){
        if(m.getHP() < m.getMaxHP()*0.2){
            team.add(m);
            System.out.println(this.getName() + " caught " + m.getName() + ".");
        }
        else{
            System.out.println(this.getName() + " failed to catch " + m.getName() + ".");
        }
    }
    public void battle(Monster m){
        activeMonster.attack(m);
    }
    public void battle(Trainer t){
        activeMonster.attack(t.getActiveMonster());
    }
    public void sureCapture(Monster m) throws AlreadyCapturedException, 
    FullTeamException {
        if(team.contains(m)){
            throw new AlreadyCapturedException("Its me, im here, deal with it");
        }
        if(team.size() > 6){
            throw new FullTeamException("Team is already full");
        }
        team.add(m);
        System.out.printf("%s was successfully captured.", m.getName());
        
    }
    public void release() throws NotInTeamException{
        boolean found = false;
        for(Monster m : team){
            if(!found){
                throw new NotInTeamException("Monster where?");
            }
            else{
        team.remove(m);
        System.out.printf("%s was released from the team.", m.getName());
    }
        }

}

    
}
